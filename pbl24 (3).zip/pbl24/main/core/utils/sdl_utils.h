#ifndef SDL_UTILS_H
#define SDL_UTILS_H

bool init_sdl(SDL *sdl, CONFIG config);
void cleanUp_sdl(SDL* sdl);


#endif