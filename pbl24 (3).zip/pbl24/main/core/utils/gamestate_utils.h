#ifndef GAMESTATE_UTILS_H
#define GAMESTATE_UTILS_H

//void checkGameStateChange(IMAGES** loadedImages, FONTS** loadedFonts, GAMESTATE* gameState, SDL_Renderer* renderer);
void checkGameStateChange(ASSETS *loadedAssets, GAMESTATE* gameState, SDL_Renderer* renderer);

#endif //GAMESTATE_UTILS_H