#ifndef GAME_H
#define GAME_H



void initialize_game(GAMEINFO *gameInfo);

void handleTurn(GAMEINFO *gameInfo);

void cleanup_game(GAMEINFO *gameInfo);




#endif // GAME_H