#ifndef LOADSCREEN_H
#define LOADSCREEN_H

GAMESTATE update_loadscreen();

#endif
