#ifndef  HOWTOPLAY_RENDER_H
#define  HOWTOPLAY_RENDER_H


int renderHowtoplay(int rend_game, SDL_Renderer *renderer, BUTTON **buttons, IMAGES *loadedImages);
void initializeButtonsH2P(BUTTON *buttons, IMAGES *loadedImages);

#endif 