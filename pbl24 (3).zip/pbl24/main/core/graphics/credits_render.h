#ifndef  CREDITS_RENDER_H
#define CREDITS_RENDER_H


int renderCredits(int rend_cred,SDL_Renderer *renderer, BUTTON **buttons, IMAGES *loadedImages);
void initializeButtonsCredits(BUTTON *buttons, IMAGES *loadedImages);

#endif 