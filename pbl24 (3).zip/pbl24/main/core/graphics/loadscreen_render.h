#ifndef LOADSCREEN_RENDER_H
#define LOADSCREEN_RENDER_H


void renderLoadscreen(SDL_Renderer *renderer, IMAGES *loadedImages);

#endif // LOADSCREEN_RENDER_H