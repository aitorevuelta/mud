#ifndef SERVER_H
#define SERVER_H

#define PORT 1234

void run_server();

#endif // SERVER_H